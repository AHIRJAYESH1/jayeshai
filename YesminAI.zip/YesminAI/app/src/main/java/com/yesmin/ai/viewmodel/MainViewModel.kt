package com.yesmin.ai.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yesmin.ai.ai.AiProvider
import com.yesmin.ai.ai.AiResult
import com.yesmin.ai.ai.ErrKind
import com.yesmin.ai.ai.GeminiProvider
import com.yesmin.ai.automation.AppInfo
import com.yesmin.ai.automation.AppLauncher
import com.yesmin.ai.automation.CommandRouter
import com.yesmin.ai.data.AppSettings
import com.yesmin.ai.data.AssistantState
import com.yesmin.ai.data.ChatMessage
import com.yesmin.ai.storage.HistoryStore
import com.yesmin.ai.storage.SettingsStore
import com.yesmin.ai.voice.VoiceManager
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SettingsStore(app)
    private val history = HistoryStore(app)
    private val router = CommandRouter(AppLauncher(app))
    private val provider: AiProvider = GeminiProvider { store.apiKey() }

    private val _state = MutableStateFlow(AssistantState.IDLE)
    val state = _state.asStateFlow()
    private val voice = VoiceManager(app) { _state.value = it }

    val settings: StateFlow<AppSettings> =
        store.flow.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    private val _messages = MutableStateFlow(history.load())
    val messages = _messages.asStateFlow()
    private val _error = MutableStateFlow<String?>(null)
    val error = _error.asStateFlow()
    private val _info = MutableStateFlow<String?>(null)
    val info = _info.asStateFlow()
    private val _coding = MutableStateFlow(false)
    val coding = _coding.asStateFlow()
    private val _choices = MutableStateFlow<List<AppInfo>>(emptyList())
    val choices = _choices.asStateFlow()
    private val _connection = MutableStateFlow(if (store.apiKey().isBlank()) "Not configured" else "Key saved")
    val connection = _connection.asStateFlow()
    private val _masked = MutableStateFlow(mask(store.apiKey()))
    val maskedKey = _masked.asStateFlow()

    private fun mask(k: String) = if (k.isBlank()) "not set" else "••••" + k.takeLast(4)

    fun notify(m: String) { _info.value = m }
    fun clearInfo() { _info.value = null }
    fun setCoding(on: Boolean) { _coding.value = on }
    fun update(f: (AppSettings) -> AppSettings) { viewModelScope.launch { store.update(f) } }
    fun voices() = voice.voices(settings.value.language)

    fun saveKey(k: String) {
        store.setApiKey(k.trim()); _masked.value = mask(k.trim())
        _connection.value = if (k.isBlank()) "Not configured" else "Key saved"
        notify("API key save ho gayi.")
    }

    fun testConnection() {
        _connection.value = "Testing…"
        viewModelScope.launch {
            val r = provider.generate(listOf(ChatMessage("user", "Say OK")), "Reply with one word.", settings.value.copy(maxTokens = 64))
            _connection.value = when (r) { is AiResult.Ok -> "Connected"; is AiResult.Err -> r.msg }
        }
    }

    private fun systemPrompt(s: AppSettings): String {
        val lang = when (s.language) {
            "english" -> "Reply in English."
            "hindi" -> "Reply in Hindi (Devanagari)."
            else -> "Reply in natural Hinglish (Roman Hindi mixed with English); match the user's language."
        }
        val pers = when (s.personality) {
            "playful" -> "warm, caring, playful and a little witty"
            "professional" -> "polite, clear and professional"
            else -> "warm, caring and friendly"
        }
        val base = "You are ${s.assistantName}, a futuristic female AI assistant, $pers. You are a fictional AI " +
            "personality and never claim to be a human. Be lighthearted and respectful. $lang " +
            "Keep answers concise because they may be spoken aloud. Never claim you performed a device action " +
            "(opening apps, sending messages, etc.) unless told it was done."
        return if (_coding.value) base + " CODING MODE: help with Python, Java, Kotlin, JavaScript, HTML, CSS, C++. " +
            "Put all code in fenced blocks with a language tag. Explain briefly. You can only write code, not run or " +
            "compile it; say so if asked to run something."
        else base
    }

    fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        voice.stopSpeaking()
        _error.value = null; _choices.value = emptyList()
        add(ChatMessage("user", text))
        val s = settings.value
        if (!_coding.value) {
            val r = router.handle(text, s)
            if (r != null) { reply(r.reply, s); _choices.value = r.choices; return }
        }
        askAi(s)
    }

    private fun askAi(s: AppSettings) {
        _state.value = AssistantState.THINKING
        viewModelScope.launch {
            val ctxMsgs = if (s.memory) _messages.value.takeLast(20) else _messages.value.takeLast(1)
            val msgs = ctxMsgs.dropWhile { it.role != "user" }
            when (val r = provider.generate(msgs, systemPrompt(s), s)) {
                is AiResult.Ok -> {
                    if (r.text.isBlank()) { _state.value = AssistantState.IDLE; _error.value = "AI ne khaali jawab diya. Retry karo." }
                    else { _connection.value = "Connected"; reply(r.text, s) }
                }
                is AiResult.Err -> {
                    _state.value = AssistantState.IDLE
                    _error.value = r.msg
                    _connection.value = if (r.kind == ErrKind.KEY) "API key problem" else if (r.kind == ErrKind.NETWORK) "Offline" else "Error"
                }
            }
        }
    }

    fun retry() { _error.value = null; askAi(settings.value) }

    private fun reply(text: String, s: AppSettings) {
        add(ChatMessage("model", text))
        if (s.voice && voice.speak(text, s.language, s.speechRate, s.voiceName)) _state.value = AssistantState.SPEAKING
        else _state.value = AssistantState.IDLE
    }

    private fun add(m: ChatMessage) {
        _messages.update { it + m }
        if (settings.value.memory) history.save(_messages.value)
    }

    fun chooseApp(a: AppInfo) { _choices.value = emptyList(); reply(router.launch(a).reply, settings.value) }

    fun startListening() {
        _error.value = null
        voice.listen(settings.value.language, { send(it) }, { _state.value = AssistantState.IDLE; notify(it) })
    }
    fun stopListening() = voice.stopListening()
    fun stopSpeaking() = voice.stopSpeaking()

    fun clearHistory() { _messages.value = emptyList(); history.clear(); notify("History clear ho gayi.") }
    fun saveSnippet(lang: String, code: String) { notify("Snippet save hua: ${history.saveSnippet(lang, code)}") }

    override fun onCleared() { voice.shutdown() }
}
