package com.yesmin.ai.automation

sealed class Cmd {
    data class Music(val query: String) : Cmd()
    data class OpenApp(val name: String) : Cmd()
    data class SystemSettings(val kind: String) : Cmd()
}

/** Pure Kotlin (unit-testable) parser for Hindi / Hinglish / English device commands. */
object CommandParser {
    private val alias = mapOf(
        "यूट्यूब" to "youtube", "खोलो" to "kholo", "खोल" to "kholo", "चलाओ" to "chalao", "चला" to "chalao",
        "सुनाओ" to "sunao", "बजाओ" to "bajao", "गाना" to "gaana", "गाने" to "gaane", "क्रोम" to "chrome",
        "सेटिंग" to "settings", "सेटिंग्स" to "settings", "मैप्स" to "maps", "ओपन" to "open", "प्ले" to "play",
        "सॉन्ग" to "song", "पर" to "par", "का" to "ka", "के" to "ke", "की" to "ki", "को" to "ko",
        "में" to "mein", "यस्मिन" to "yesmin", "करो" to "karo", "वाईफाई" to "wifi", "ब्लूटूथ" to "bluetooth"
    )
    private val openVerbs = setOf("kholo", "khol", "open", "launch", "start", "chalu")
    private val musicVerbs = setOf("chalao", "chala", "play", "sunao", "bajao", "sunna", "laga", "lagao")
    private val hindiNouns = setOf("gaana", "gaane", "gana", "gane")
    private val musicNouns = hindiNouns + setOf("song", "songs", "music", "video")
    private val fillers = setOf(
        "yesmin", "yasmin", "par", "pe", "on", "me", "mein", "ka", "ke", "ki", "ko", "ek", "mujhe", "please",
        "plz", "karo", "kar", "do", "de", "dijiye", "hai", "se", "the", "a", "app", "aur", "mere", "liye",
        "for", "my", "zara", "phone"
    )

    fun parse(input: String): Cmd? {
        val w = input.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N} ]"), " ")
            .split(Regex("\\s+")).filter { it.isNotBlank() }.map { alias[it] ?: it }
        if (w.isEmpty() || w.size > 12) return null
        val hasYt = "youtube" in w
        val hasOpen = w.any { it in openVerbs }
        val hasMusicVerb = w.any { it in musicVerbs }
        val hasNoun = w.any { it in musicNouns }

        if ("settings" in w && (hasOpen || w.size <= 3)) {
            val kind = when {
                "wifi" in w -> "wifi"
                "bluetooth" in w -> "bluetooth"
                "sound" in w || "volume" in w -> "sound"
                "display" in w || "brightness" in w -> "display"
                else -> "main"
            }
            return Cmd.SystemSettings(kind)
        }
        if ((hasMusicVerb && (hasNoun || hasYt)) || (hasYt && hasNoun)) {
            val drop = openVerbs + musicVerbs + musicNouns + fillers + "youtube"
            var q = w.filter { it !in drop }.joinToString(" ")
            if (q.isNotBlank() && w.any { it in hindiNouns }) q += " songs"
            return Cmd.Music(q)
        }
        if (hasOpen) {
            val name = w.filter { it !in openVerbs && it !in fillers }.joinToString(" ")
            return if (name.isBlank()) null else Cmd.OpenApp(name)
        }
        return null
    }
}
