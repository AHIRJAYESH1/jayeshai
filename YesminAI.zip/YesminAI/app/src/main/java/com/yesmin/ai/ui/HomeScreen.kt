package com.yesmin.ai.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yesmin.ai.data.AssistantState
import com.yesmin.ai.viewmodel.MainViewModel

@Composable
fun HomeScreen(vm: MainViewModel, onSettings: () -> Unit, onHistory: () -> Unit) {
    val ctx = LocalContext.current
    val state by vm.state.collectAsStateWithLifecycle()
    val msgs by vm.messages.collectAsStateWithLifecycle()
    val s by vm.settings.collectAsStateWithLifecycle()
    val err by vm.error.collectAsStateWithLifecycle()
    val conn by vm.connection.collectAsStateWithLifecycle()
    val coding by vm.coding.collectAsStateWithLifecycle()
    val choices by vm.choices.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    var rationale by remember { mutableStateOf(false) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.startListening()
        else vm.notify("Mic permission nahi mili. Text se baat karo, ya Settings → Privacy se permission do.")
    }
    fun onMic() {
        if (state == AssistantState.LISTENING) { vm.stopListening(); return }
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (granted) vm.startListening() else rationale = true
    }
    if (rationale) AlertDialog(
        onDismissRequest = { rationale = false },
        title = { Text("Microphone permission") },
        text = {
            Text("Voice commands ke liye mic chahiye. Mic sirf tab chalta hai jab aap mic button dabate ho. " +
                "Awaaz ko Android ki speech service (aksar Google) process karti hai; Yesmin audio save nahi karta.")
        },
        confirmButton = { TextButton(onClick = { rationale = false; permLauncher.launch(Manifest.permission.RECORD_AUDIO) }) { Text("Allow") } },
        dismissButton = { TextButton(onClick = { rationale = false }) { Text("Not now") } }
    )

    val label = when (state) {
        AssistantState.LISTENING -> "Sun rahi hoon…"
        AssistantState.THINKING -> "Soch rahi hoon…"
        AssistantState.SPEAKING -> "Bol rahi hoon…"
        AssistantState.IDLE -> "Ready"
    }
    val wave = if (state == AssistantState.LISTENING) Cyan else Purple

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(MaterialTheme.colorScheme.background, MaterialTheme.colorScheme.surface)))) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("YESMIN AI", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                        letterSpacing = 3.sp, color = MaterialTheme.colorScheme.primary)
                    Text("Your Personal AI Assistant", style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = onHistory) { Icon(Icons.Default.History, "History") }
                IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Settings") }
            }
            Text("● Gemini: $conn", fontSize = 11.sp,
                color = if (conn == "Connected") Color(0xFF34D399) else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
            Orb(state, s.animations)
            Text(label, style = MaterialTheme.typography.labelLarge)
            Waveform(state == AssistantState.LISTENING || state == AssistantState.SPEAKING, s.animations, wave)
            if (state == AssistantState.SPEAKING) {
                OutlinedButton(onClick = { vm.stopSpeaking() }) { Icon(Icons.Default.Stop, null); Spacer(Modifier.width(6.dp)); Text("Stop speaking") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(!coding, { vm.setCoding(false) }, { Text("Chat") })
                FilterChip(coding, { vm.setCoding(true) }, { Text("Coding") })
            }

            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(vertical = 6.dp)) {
                AnimatedContent(targetState = msgs.lastOrNull(), label = "resp") { m ->
                    if (m == null) Text("Hey! Main yahin hoon. Batao, aaj kya karna hai?")
                    else MessageView(m, vm)
                }
                if (choices.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    choices.forEach { a -> AssistChip(onClick = { vm.chooseApp(a) }, label = { Text(a.label) }) }
                }
                err?.let {
                    Card(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(it)
                            TextButton(onClick = { vm.retry() }) { Text("Retry") }
                        }
                    }
                }
            }

            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("YouTube" to "YouTube kholo", "Chrome" to "Chrome open karo", "Maps" to "Maps kholo", "Settings" to "Settings kholo")
                    .forEach { (l, c) -> AssistChip(onClick = { vm.send(c) }, label = { Text(l) }) }
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilledIconButton(onClick = { onMic() }) {
                    Icon(if (state == AssistantState.LISTENING) Icons.Default.Stop else Icons.Default.Mic, "Mic")
                }
                OutlinedTextField(
                    value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                    placeholder = { Text(if (coding) "Code ke baare mein poocho…" else "Yesmin se baat karo…") },
                    maxLines = 3,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { vm.send(input); input = "" })
                )
                IconButton(onClick = { vm.send(input); input = "" }) { Icon(Icons.AutoMirrored.Filled.Send, "Send") }
            }
        }
    }
}
