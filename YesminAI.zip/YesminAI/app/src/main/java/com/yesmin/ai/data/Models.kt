package com.yesmin.ai.data

enum class AssistantState { IDLE, LISTENING, THINKING, SPEAKING }

/** role is "user" or "model" (Gemini naming). */
data class ChatMessage(val role: String, val text: String, val time: Long = System.currentTimeMillis())

data class AppSettings(
    val assistantName: String = "Yesmin",
    val model: String = "gemini-2.5-flash",
    val language: String = "hinglish",      // hinglish | hindi | english
    val personality: String = "friendly",   // friendly | playful | professional
    val maxTokens: Int = 1024,
    val memory: Boolean = true,
    val voice: Boolean = true,
    val creativity: Float = 0.7f,
    val speechRate: Float = 1.0f,
    val voiceName: String = "",
    val theme: String = "dark",             // dark | light | system
    val animations: Boolean = true,
    val musicApp: String = "youtube"        // youtube | ytmusic
)
