package com.yesmin.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.yesmin.ai.data.AssistantState
import java.util.Locale

class VoiceManager(private val ctx: Context, private val onState: (AssistantState) -> Unit) {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null

    init {
        tts = TextToSpeech(ctx) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { onState(AssistantState.SPEAKING) }
                override fun onDone(utteranceId: String?) { onState(AssistantState.IDLE) }
                override fun onError(utteranceId: String?) { onState(AssistantState.IDLE) }
            })
        }
    }

    private fun localeFor(lang: String) = if (lang == "english") Locale("en", "IN") else Locale("hi", "IN")

    fun voices(lang: String): List<String> =
        try {
            tts?.voices?.filter { it.locale.language == localeFor(lang).language }
                ?.map { it.name }?.sorted()?.take(8) ?: emptyList()
        } catch (e: Exception) { emptyList() }

    private fun clean(t: String): String =
        t.replace(Regex("```[\\s\\S]*?```"), " code upar likha hai. ")
            .replace(Regex("[*#`_>]"), "")

    fun speak(text: String, lang: String, rate: Float, voiceName: String): Boolean {
        val t = tts ?: return false
        if (!ttsReady) return false
        t.language = localeFor(lang)
        if (voiceName.isNotBlank()) t.voices?.firstOrNull { it.name == voiceName }?.let { t.voice = it }
        t.setSpeechRate(rate)
        t.speak(clean(text).take(3900), TextToSpeech.QUEUE_FLUSH, null, "yesmin")
        return true
    }

    fun stopSpeaking() { tts?.stop(); onState(AssistantState.IDLE) }

    fun listen(lang: String, onResult: (String) -> Unit, onError: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onError("Is device par speech recognition available nahi hai. Text se likh kar baat karo.")
            return
        }
        stopSpeaking()
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onError(error: Int) {
                onState(AssistantState.IDLE)
                onError(
                    when (error) {
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                            "Network problem: speech recognition ke liye internet chahiye ho sakta hai."
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                            "Kuch sunai nahi diya. Phir se bolo."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                            "Microphone permission chahiye. Settings → Privacy se allow karo."
                        SpeechRecognizer.ERROR_AUDIO -> "Microphone mein problem hai."
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy hai, ek second baad try karo."
                        else -> "Awaaz samajh nahi aayi (code $error)."
                    }
                )
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text.isNullOrBlank()) { onState(AssistantState.IDLE); onError("Kuch sunai nahi diya. Phir se bolo.") }
                else onResult(text)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeFor(lang).toLanguageTag())
        onState(AssistantState.LISTENING)
        r.startListening(i)
    }

    fun stopListening() { recognizer?.stopListening() }

    fun shutdown() {
        recognizer?.destroy(); tts?.stop(); tts?.shutdown()
    }
}
