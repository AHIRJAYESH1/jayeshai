package com.yesmin.ai.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yesmin.ai.data.AssistantState
import com.yesmin.ai.data.ChatMessage
import com.yesmin.ai.viewmodel.MainViewModel
import kotlin.math.abs
import kotlin.math.sin

@Composable
fun Orb(state: AssistantState, animate: Boolean, modifier: Modifier = Modifier) {
    val color = when (state) {
        AssistantState.LISTENING -> Cyan
        AssistantState.THINKING -> Purple
        AssistantState.SPEAKING -> Blue
        AssistantState.IDLE -> Color(0xFF60A5FA)
    }
    var pulse = 1f
    var rot = 0f
    if (animate) {
        val t = rememberInfiniteTransition(label = "orb")
        val ms = when (state) {
            AssistantState.SPEAKING -> 600; AssistantState.LISTENING -> 900
            AssistantState.THINKING -> 1200; AssistantState.IDLE -> 2600
        }
        val p by t.animateFloat(0.94f, 1.06f, infiniteRepeatable(tween(ms, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p")
        val r by t.animateFloat(0f, 360f, infiniteRepeatable(tween(if (state == AssistantState.THINKING) 1500 else 8000, easing = LinearEasing)), label = "r")
        pulse = p; rot = r
    }
    Canvas(modifier.size(170.dp)) {
        val c = center
        val big = size.minDimension / 2
        val r = big * 0.55f * pulse
        drawCircle(Brush.radialGradient(listOf(color.copy(alpha = 0.45f), Color.Transparent), center = c, radius = big), radius = big, center = c)
        drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.9f), color, Purple), center = c, radius = r), radius = r, center = c)
        rotate(rot, pivot = c) {
            val tl = Offset(c.x - r * 1.3f, c.y - r * 1.3f)
            val sz = Size(r * 2.6f, r * 2.6f)
            val st = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
            drawArc(Cyan, 0f, 110f, false, topLeft = tl, size = sz, style = st)
            drawArc(Purple, 180f, 110f, false, topLeft = tl, size = sz, style = st)
        }
    }
}

@Composable
fun Waveform(active: Boolean, animate: Boolean, color: Color, modifier: Modifier = Modifier) {
    var phase = 0f
    if (active && animate) {
        val t = rememberInfiniteTransition(label = "w")
        val p by t.animateFloat(0f, (2 * Math.PI).toFloat(), infiniteRepeatable(tween(1000, easing = LinearEasing)), label = "wp")
        phase = p
    }
    Canvas(modifier.fillMaxWidth().height(32.dp)) {
        val n = 28
        val gap = size.width / n
        for (i in 0 until n) {
            val h = if (active) (0.25f + 0.75f * abs(sin(phase + i * 0.5f))) * size.height else 3.dp.toPx()
            val x = gap * i + gap / 2
            drawLine(color, Offset(x, (size.height - h) / 2), Offset(x, (size.height + h) / 2), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
        }
    }
}

@Composable
fun CodeBlock(lang: String, code: String, vm: MainViewModel) {
    val clip = LocalClipboardManager.current
    Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFF0B1020), modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Column(Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(lang.ifBlank { "code" }, color = Cyan, style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
                IconButton(onClick = { clip.setText(AnnotatedString(code)); vm.notify("Copy ho gaya") }) {
                    Icon(Icons.Default.ContentCopy, "Copy", tint = Color.White)
                }
                IconButton(onClick = { vm.saveSnippet(lang, code) }) {
                    Icon(Icons.Default.Save, "Save snippet", tint = Color.White)
                }
            }
            Text(code, fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Color(0xFFE2E8F0),
                modifier = Modifier.horizontalScroll(rememberScrollState()))
        }
    }
}

@Composable
fun MessageView(msg: ChatMessage, vm: MainViewModel) {
    if (msg.role == "user") {
        Box(Modifier.fillMaxWidth().padding(vertical = 4.dp), contentAlignment = Alignment.CenterEnd) {
            Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)) {
                Text(msg.text, Modifier.padding(10.dp))
            }
        }
    } else {
        Column(Modifier.fillMaxWidth()) {
            msg.text.split("```").forEachIndexed { i, p ->
                if (i % 2 == 0) {
                    if (p.isNotBlank()) Text(p.trim(), modifier = Modifier.padding(vertical = 4.dp))
                } else {
                    val nl = p.indexOf('\n')
                    val lang = if (nl >= 0) p.substring(0, nl).trim() else ""
                    val code = (if (nl >= 0) p.substring(nl + 1) else p).trimEnd()
                    CodeBlock(lang, code, vm)
                }
            }
        }
    }
}
