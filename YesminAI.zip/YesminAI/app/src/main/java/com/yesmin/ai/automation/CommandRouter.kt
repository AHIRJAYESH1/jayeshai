package com.yesmin.ai.automation

import com.yesmin.ai.data.AppSettings

class CommandRouter(private val launcher: AppLauncher) {
    data class Result(val reply: String, val choices: List<AppInfo> = emptyList())

    /** Returns null when the text is not a device command (so it goes to the AI). */
    fun handle(text: String, s: AppSettings): Result? = when (val c = CommandParser.parse(text)) {
        null -> null
        is Cmd.Music ->
            if (c.query.isBlank()) Result("Bilkul! Kaunsa gaana ya artist sunna hai?")
            else if (launcher.youtubeSearch(c.query, s.musicApp == "ytmusic"))
                Result("Bilkul! ${c.query} search kar rahi hoon.")
            else Result("Mujhse YouTube ya browser nahi khul paya.")
        is Cmd.SystemSettings ->
            if (launcher.openSettings(c.kind)) Result("Settings khol rahi hoon.") else Result("Settings nahi khul payi.")
        is Cmd.OpenApp -> {
            val m = launcher.find(c.name)
            when {
                m.isEmpty() -> Result("'${c.name}' mujhe installed apps mein nahi mila.")
                m.size == 1 -> launch(m[0])
                else -> Result("Kaunsa kholu? Ek chuno:", m.take(6))
            }
        }
    }

    fun launch(app: AppInfo): Result =
        if (launcher.launch(app.pkg)) Result("${app.label} khol rahi hoon.") else Result("${app.label} nahi khul paya.")
}
