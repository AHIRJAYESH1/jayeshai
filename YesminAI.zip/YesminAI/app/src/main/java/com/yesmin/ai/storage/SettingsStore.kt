package com.yesmin.ai.storage

import android.content.Context
import android.content.SharedPreferences
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.yesmin.ai.data.AppSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("yesmin_settings")

class SettingsStore(private val ctx: Context) {
    private val kName = stringPreferencesKey("name")
    private val kModel = stringPreferencesKey("model")
    private val kLang = stringPreferencesKey("language")
    private val kPers = stringPreferencesKey("personality")
    private val kMax = intPreferencesKey("max_tokens")
    private val kMem = booleanPreferencesKey("memory")
    private val kVoice = booleanPreferencesKey("voice")
    private val kCreat = floatPreferencesKey("creativity")
    private val kRate = floatPreferencesKey("rate")
    private val kVName = stringPreferencesKey("voice_name")
    private val kTheme = stringPreferencesKey("theme")
    private val kAnim = booleanPreferencesKey("animations")
    private val kMusic = stringPreferencesKey("music_app")

    val flow: Flow<AppSettings> = ctx.dataStore.data.map { p ->
        val d = AppSettings()
        AppSettings(
            assistantName = p[kName] ?: d.assistantName,
            model = p[kModel] ?: d.model,
            language = p[kLang] ?: d.language,
            personality = p[kPers] ?: d.personality,
            maxTokens = p[kMax] ?: d.maxTokens,
            memory = p[kMem] ?: d.memory,
            voice = p[kVoice] ?: d.voice,
            creativity = p[kCreat] ?: d.creativity,
            speechRate = p[kRate] ?: d.speechRate,
            voiceName = p[kVName] ?: d.voiceName,
            theme = p[kTheme] ?: d.theme,
            animations = p[kAnim] ?: d.animations,
            musicApp = p[kMusic] ?: d.musicApp
        )
    }

    suspend fun update(f: (AppSettings) -> AppSettings) {
        val n = f(flow.first())
        ctx.dataStore.edit { p ->
            p[kName] = n.assistantName; p[kModel] = n.model; p[kLang] = n.language
            p[kPers] = n.personality; p[kMax] = n.maxTokens; p[kMem] = n.memory
            p[kVoice] = n.voice; p[kCreat] = n.creativity; p[kRate] = n.speechRate
            p[kVName] = n.voiceName; p[kTheme] = n.theme; p[kAnim] = n.animations
            p[kMusic] = n.musicApp
        }
    }

    // API key lives in EncryptedSharedPreferences (Android Keystore). It is never logged.
    private val prefs: SharedPreferences by lazy {
        try {
            EncryptedSharedPreferences.create(
                ctx, "yesmin_secure",
                MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            // Keystore unavailable on some devices: fall back to app-private storage.
            ctx.getSharedPreferences("yesmin_fallback", Context.MODE_PRIVATE)
        }
    }

    fun apiKey(): String = prefs.getString("gemini_key", "") ?: ""
    fun setApiKey(k: String) { prefs.edit().putString("gemini_key", k).apply() }
}
