package com.yesmin.ai.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yesmin.ai.viewmodel.MainViewModel

@Composable
fun HistoryScreen(vm: MainViewModel, onBack: () -> Unit) {
    val msgs by vm.messages.collectAsStateWithLifecycle()
    var confirm by remember { mutableStateOf(false) }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("History clear karein?") },
        text = { Text("Saari conversation history delete ho jayegi.") },
        confirmButton = { TextButton(onClick = { vm.clearHistory(); confirm = false }) { Text("Clear") } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
    )
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Text("Conversation history", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            IconButton(onClick = { confirm = true }) { Icon(Icons.Default.Delete, "Clear") }
        }
        if (msgs.isEmpty()) Text("Abhi koi history nahi hai.", modifier = Modifier.padding(16.dp))
        LazyColumn(Modifier.weight(1f)) { items(msgs) { MessageView(it, vm) } }
    }
}
