package com.yesmin.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.yesmin.ai.ui.HistoryScreen
import com.yesmin.ai.ui.HomeScreen
import com.yesmin.ai.ui.SettingsScreen
import com.yesmin.ai.ui.YesminTheme
import com.yesmin.ai.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: MainViewModel = viewModel()
            val s by vm.settings.collectAsStateWithLifecycle()
            YesminTheme(s.theme) { Root(vm) }
        }
    }
}

@Composable
fun Root(vm: MainViewModel) {
    var screen by rememberSaveable { mutableStateOf("home") }
    val snack = remember { SnackbarHostState() }
    val info by vm.info.collectAsStateWithLifecycle()
    LaunchedEffect(info) { info?.let { snack.showSnackbar(it); vm.clearInfo() } }
    BackHandler(screen != "home") { screen = "home" }
    Scaffold(snackbarHost = { SnackbarHost(snack) }, containerColor = MaterialTheme.colorScheme.background) { pad ->
        Box(Modifier.padding(pad)) {
            when (screen) {
                "settings" -> SettingsScreen(vm) { screen = "home" }
                "history" -> HistoryScreen(vm) { screen = "home" }
                else -> HomeScreen(vm, { screen = "settings" }, { screen = "history" })
            }
        }
    }
}
