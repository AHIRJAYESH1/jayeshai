package com.yesmin.ai.ai

import com.yesmin.ai.data.AppSettings
import com.yesmin.ai.data.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class GeminiProvider(private val key: () -> String) : AiProvider {
    override val id = "gemini"

    override suspend fun generate(history: List<ChatMessage>, system: String, s: AppSettings): AiResult =
        withContext(Dispatchers.IO) {
            val k = key()
            if (k.isBlank()) return@withContext AiResult.Err(
                ErrKind.KEY, "API key set nahi hai. Settings → AI Settings mein Gemini key daalo."
            )
            try {
                val contents = JSONArray()
                history.forEach {
                    contents.put(
                        JSONObject().put("role", it.role)
                            .put("parts", JSONArray().put(JSONObject().put("text", it.text)))
                    )
                }
                val gen = JSONObject()
                    .put("temperature", s.creativity.toDouble())
                    .put("maxOutputTokens", s.maxTokens)
                // Flash models: skip "thinking" so the token budget goes to the visible answer.
                if (s.model.contains("flash")) gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                    .put("contents", contents)
                    .put("generationConfig", gen)

                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${s.model.trim()}:generateContent")
                val c = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 15000; readTimeout = 60000; doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("x-goog-api-key", k)
                }
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val code = c.responseCode
                val text = (if (code in 200..299) c.inputStream else c.errorStream)
                    ?.bufferedReader()?.use { it.readText() }.orEmpty()
                c.disconnect()
                map(code, text)
            } catch (e: IOException) {
                AiResult.Err(ErrKind.NETWORK, "Internet connection check karo, phir Retry dabao.")
            } catch (e: Exception) {
                AiResult.Err(ErrKind.OTHER, "Kuch galat ho gaya: ${e.javaClass.simpleName}")
            }
        }

    private fun map(code: Int, text: String): AiResult {
        if (code in 200..299) {
            val parts = JSONObject(text).optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")
            val sb = StringBuilder()
            if (parts != null) for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
            return AiResult.Ok(sb.toString().trim())
        }
        val apiMsg = try { JSONObject(text).getJSONObject("error").getString("message") } catch (e: Exception) { "" }
        return when {
            code == 429 -> AiResult.Err(ErrKind.RATE, "Rate limit ho gayi. Thodi der baad Retry karo.")
            code in 500..599 -> AiResult.Err(ErrKind.SERVER, "Gemini service abhi problem mein hai. Thodi der baad Retry karo.")
            code == 404 -> AiResult.Err(ErrKind.OTHER, "Ye model nahi mila. Settings mein dusra model chuno.")
            code == 401 || code == 403 || apiMsg.contains("API key", true) ->
                AiResult.Err(ErrKind.KEY, "API key galat ya band hai. Settings mein sahi Gemini key daalo.")
            else -> AiResult.Err(ErrKind.OTHER, "Gemini error ($code): ${apiMsg.take(150)}")
        }
    }
}
