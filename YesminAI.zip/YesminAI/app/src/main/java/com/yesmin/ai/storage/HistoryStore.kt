package com.yesmin.ai.storage

import android.content.Context
import com.yesmin.ai.data.ChatMessage
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class HistoryStore(private val ctx: Context) {
    private val file get() = File(ctx.filesDir, "history.json")

    fun load(): List<ChatMessage> = try {
        val a = JSONArray(file.readText())
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            ChatMessage(o.getString("r"), o.getString("t"), o.optLong("ts"))
        }
    } catch (e: Exception) { emptyList() }

    fun save(list: List<ChatMessage>) {
        try {
            val a = JSONArray()
            list.takeLast(200).forEach {
                a.put(JSONObject().put("r", it.role).put("t", it.text).put("ts", it.time))
            }
            file.writeText(a.toString())
        } catch (e: Exception) { /* ignore disk errors */ }
    }

    fun clear() { file.delete() }

    /** Saves a code snippet under files/snippets/. Returns the file name. */
    fun saveSnippet(lang: String, code: String): String {
        val dir = File(ctx.filesDir, "snippets").apply { mkdirs() }
        val ext = when (lang.lowercase()) {
            "kotlin", "kt" -> "kt"; "python", "py" -> "py"; "java" -> "java"
            "javascript", "js" -> "js"; "html" -> "html"; "css" -> "css"
            "cpp", "c++", "c" -> "cpp"; else -> "txt"
        }
        val f = File(dir, "snippet_${System.currentTimeMillis()}.$ext")
        f.writeText(code)
        return f.name
    }
}
