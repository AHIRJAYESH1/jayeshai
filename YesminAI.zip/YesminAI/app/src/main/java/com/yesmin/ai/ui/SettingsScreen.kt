package com.yesmin.ai.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yesmin.ai.viewmodel.MainViewModel

@Composable
private fun Section(t: String) =
    Text(t, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 14.dp))

@Composable
private fun <T> Choice(label: String, options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    Text(label, style = MaterialTheme.typography.labelLarge)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (v, l) -> FilterChip(selected == v, { onSelect(v) }, { Text(l) }) }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) =
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f)); Switch(checked, onChange)
    }

@Composable
private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, steps: Int, fmt: (Float) -> String, onDone: (Float) -> Unit) {
    var v by remember { mutableStateOf(value) }
    Text("$label: ${fmt(v)}", style = MaterialTheme.typography.labelLarge)
    Slider(v, { v = it }, valueRange = range, steps = steps, onValueChangeFinished = { onDone(v) })
}

@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val s by vm.settings.collectAsStateWithLifecycle()
    val conn by vm.connection.collectAsStateWithLifecycle()
    val masked by vm.maskedKey.collectAsStateWithLifecycle()
    var keyInput by remember { mutableStateOf("") }
    var name by remember { mutableStateOf(s.assistantName) }
    var model by remember { mutableStateOf(s.model) }
    val micOk = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Text("Settings", style = MaterialTheme.typography.headlineSmall)
        }

        Section("AI Settings")
        Choice("Provider", listOf("gemini" to "Google Gemini"), "gemini") {}
        Text("Dusre providers abhi available nahi hain.", style = MaterialTheme.typography.bodySmall)
        Choice("Model", listOf("gemini-2.5-flash" to "2.5 Flash", "gemini-2.5-flash-lite" to "2.5 Flash-Lite", "gemini-2.5-pro" to "2.5 Pro"), s.model) {
            model = it; vm.update { c -> c.copy(model = it) }
        }
        OutlinedTextField(model, { model = it; vm.update { c -> c.copy(model = it.trim()) } },
            label = { Text("Model ID (custom bhi likh sakte ho)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(keyInput, { keyInput = it }, label = { Text("Gemini API key (current: $masked)") },
            singleLine = true, visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, autoCorrect = false), modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.saveKey(keyInput); keyInput = "" }, enabled = keyInput.isNotBlank()) { Text("Save key") }
            OutlinedButton(onClick = { vm.testConnection() }) { Text("Test connection") }
        }
        Text("Status: $conn")
        Text("Key aapke phone mein encrypted storage mein rehti hai aur sirf Google Gemini API ko bheji jati hai. " +
            "Ye kabhi log nahi hoti.", style = MaterialTheme.typography.bodySmall)
        SliderRow("Max response length", s.maxTokens.toFloat(), 256f..4096f, 14, { "${it.toInt()} tokens" }) { v -> vm.update { c -> c.copy(maxTokens = v.toInt()) } }
        SliderRow("Creativity", s.creativity, 0f..1f, 9, { "%.1f".format(it) }) { v -> vm.update { c -> c.copy(creativity = v) } }

        Section("Assistant Settings")
        OutlinedTextField(name, { name = it; vm.update { c -> c.copy(assistantName = it.ifBlank { "Yesmin" }) } },
            label = { Text("Assistant name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Choice("Language", listOf("hinglish" to "Hinglish", "hindi" to "हिन्दी", "english" to "English"), s.language) {
            vm.update { c -> c.copy(language = it, voiceName = "") }
        }
        Choice("Voice", listOf("" to "Default") + vm.voices().map { it to it }, s.voiceName) { vm.update { c -> c.copy(voiceName = it) } }
        SliderRow("Speaking speed", s.speechRate, 0.5f..2f, 5, { "%.2fx".format(it) }) { v -> vm.update { c -> c.copy(speechRate = v) } }
        Choice("Personality", listOf("friendly" to "Friendly", "playful" to "Playful", "professional" to "Professional"), s.personality) {
            vm.update { c -> c.copy(personality = it) }
        }
        SwitchRow("Voice response", s.voice) { v -> vm.update { c -> c.copy(voice = v) } }

        Section("Privacy Settings")
        SwitchRow("Conversation memory", s.memory) { v -> vm.update { c -> c.copy(memory = v) } }
        OutlinedButton(onClick = { vm.clearHistory() }) { Text("Clear history") }
        Text("Microphone permission: ${if (micOk) "granted" else "not granted"}")
        OutlinedButton(onClick = {
            ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
        }) { Text("App permissions kholo") }
        Text("Mic sirf mic button dabane par chalta hai. Aapke messages Gemini ko bheje jaate hain jab aap AI se baat karte ho.",
            style = MaterialTheme.typography.bodySmall)

        Section("App Settings")
        Choice("Theme", listOf("dark" to "Dark", "light" to "Light", "system" to "System"), s.theme) { vm.update { c -> c.copy(theme = it) } }
        SwitchRow("Animations", s.animations) { v -> vm.update { c -> c.copy(animations = v) } }
        Choice("Default music app", listOf("youtube" to "YouTube", "ytmusic" to "YouTube Music"), s.musicApp) { vm.update { c -> c.copy(musicApp = it) } }
        Section("About")
        Text("Yesmin AI v1.0 — ek fictional AI assistant, real insaan nahi.", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(24.dp))
    }
}
