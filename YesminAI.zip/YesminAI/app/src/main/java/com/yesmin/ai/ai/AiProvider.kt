package com.yesmin.ai.ai

import com.yesmin.ai.data.AppSettings
import com.yesmin.ai.data.ChatMessage

enum class ErrKind { NETWORK, KEY, RATE, SERVER, OTHER }

sealed class AiResult {
    data class Ok(val text: String) : AiResult()
    data class Err(val kind: ErrKind, val msg: String) : AiResult()
}

/** Add new providers (OpenAI-compatible, local, ...) by implementing this interface. */
interface AiProvider {
    val id: String
    suspend fun generate(history: List<ChatMessage>, system: String, s: AppSettings): AiResult
}
