package com.yesmin.ai.automation

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import java.net.URLEncoder

data class AppInfo(val label: String, val pkg: String)

/** Launches apps only via standard intents. Never clicks, types or sends anything for the user. */
class AppLauncher(private val ctx: Context) {
    private val pm get() = ctx.packageManager

    fun installed(): List<AppInfo> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
    }

    fun find(name: String): List<AppInfo> {
        val n = name.lowercase().trim()
        val apps = installed()
        val exact = apps.filter { it.label.lowercase() == n }
        if (exact.isNotEmpty()) return exact
        return apps.filter { val l = it.label.lowercase(); l.contains(n) || (l.length >= 4 && n.contains(l)) }
    }

    fun launch(pkg: String): Boolean = try {
        val i = pm.getLaunchIntentForPackage(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (i == null) false else { ctx.startActivity(i); true }
    } catch (e: Exception) { false }

    fun youtubeSearch(query: String, music: Boolean): Boolean {
        val q = URLEncoder.encode(query, "UTF-8")
        val uri = if (music) "https://music.youtube.com/search?q=$q" else "https://www.youtube.com/results?search_query=$q"
        val pkg = if (music) "com.google.android.apps.youtube.music" else "com.google.android.youtube"
        val base = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(Intent(base).setPackage(pkg)); true
        } catch (e: ActivityNotFoundException) {
            try { ctx.startActivity(Intent(base)); true } catch (e2: Exception) { false }  // browser fallback
        }
    }

    fun openSettings(kind: String): Boolean {
        val action = when (kind) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return try { ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } catch (e: Exception) { false }
    }
}
