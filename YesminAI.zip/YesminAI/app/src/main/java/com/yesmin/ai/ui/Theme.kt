package com.yesmin.ai.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Cyan = Color(0xFF22D3EE)
val Purple = Color(0xFF8B5CF6)
val Blue = Color(0xFF3B82F6)

private val Dark = darkColorScheme(
    primary = Cyan, secondary = Purple, tertiary = Blue,
    background = Color(0xFF05060F), surface = Color(0xFF0E1124),
    onBackground = Color(0xFFE2E8F0), onSurface = Color(0xFFE2E8F0)
)
private val Light = lightColorScheme(primary = Color(0xFF0277BD), secondary = Color(0xFF6A1B9A), tertiary = Blue)

@Composable
fun YesminTheme(mode: String, content: @Composable () -> Unit) {
    val dark = mode == "dark" || (mode == "system" && isSystemInDarkTheme())
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
