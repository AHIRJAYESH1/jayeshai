package com.yesmin.ai

import com.yesmin.ai.automation.Cmd
import com.yesmin.ai.automation.CommandParser
import org.junit.Assert.*
import org.junit.Test

class CommandParserTest {
    @Test fun musicSearch() =
        assertEquals(Cmd.Music("arijit singh songs"), CommandParser.parse("YouTube par Arijit Singh ke gaane chalao"))
    @Test fun openYoutube() = assertEquals(Cmd.OpenApp("youtube"), CommandParser.parse("YouTube kholo"))
    @Test fun openChrome() = assertEquals(Cmd.OpenApp("chrome"), CommandParser.parse("Chrome open karo"))
    @Test fun settings() = assertEquals(Cmd.SystemSettings("main"), CommandParser.parse("Settings kholo"))
    @Test fun codingGoesToAi() = assertNull(CommandParser.parse("Mujhe Python coding mein help chahiye"))
    @Test fun devanagari() = assertEquals(Cmd.OpenApp("youtube"), CommandParser.parse("यूट्यूब खोलो"))
}
